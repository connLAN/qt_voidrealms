#include "myclass.h"

myclass::myclass()
{
}
