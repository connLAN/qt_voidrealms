#include "test.h"

Test::Test(QObject *parent) :
    QObject(parent)
{
    mChild = new Child(this);
}
