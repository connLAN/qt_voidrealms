#include "mylib.h"


MyLib::MyLib()
{
}

void MyLib::Test()
{
    qDebug() << "Hello from our DLL";
    // .so
}
