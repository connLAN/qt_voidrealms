#ifndef MYLIB_H
#define MYLIB_H

#include "MyLib_global.h"
#include <QDebug>

class MYLIBSHARED_EXPORT MyLib {
public:
    MyLib();

    void Test();
};

#endif // MYLIB_H
