#include "statlib.h"


StatLib::StatLib()
{
}

void StatLib::Test()
{
    qDebug() << "Hello from the static lib";
}
