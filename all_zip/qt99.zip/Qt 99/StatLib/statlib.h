#ifndef STATLIB_H
#define STATLIB_H

#include <QDebug>

class StatLib {
public:
    StatLib();
    void Test();
};

#endif // STATLIB_H
