#ifndef PERSON_H
#define PERSON_H

#include <QtCore>

class Person
{
public:
    int Age;
    QString Name;
};

#endif // PERSON_H
